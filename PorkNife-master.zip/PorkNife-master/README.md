# PorkNife
A fun first-person 3D raycasting-based Maze-solving RPG for ICS4U1

Epic Doom-style 3D Maze solving 

Thanks to the electric sheep for help with implementing the raycasting engine


![The Goal blocks](https://drive.google.com/file/d/1uIGWiwzssrPVwvO6veZpsKb8jvCEz2CW/view?usp=sharing)
